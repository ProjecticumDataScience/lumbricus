import Straw from './straw.js';
export default Straw;