const sampleInfoTileXShim = 8
const sampleInfoTileWidth = 16

export {sampleInfoTileWidth, sampleInfoTileXShim}