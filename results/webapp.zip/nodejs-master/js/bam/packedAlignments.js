

class PackedAlignments {

    constructor() {
    }

    pack() {

    }

    repack() {

    }

}


export default PackedAlignments