const _version = "3.1.2"
function version() {
    return _version
}
export default version
