To run the examples you must first build from the project root the dist directory from the project root

> npm run build

